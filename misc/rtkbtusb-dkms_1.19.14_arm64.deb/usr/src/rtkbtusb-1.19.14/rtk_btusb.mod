/home/unitree/share/G1-NX/g1_rtl8852bu_driver/rtkbtusb-1.19.14/rtk_coex.o /home/unitree/share/G1-NX/g1_rtl8852bu_driver/rtkbtusb-1.19.14/rtk_misc.o /home/unitree/share/G1-NX/g1_rtl8852bu_driver/rtkbtusb-1.19.14/rtk_bt.o

